---
name: notion-navigation
description: "Hvordan Claude skal navigere NOVOOI sitt Notion-workspace. Bruk alltid denne skillen når noen spør om å finne, lage, oppdatere eller søke etter sider, databaser, prosjekter, oppgaver, møtenotater, investorkontakter, salgspipeline, regnskap, kommunikasjonsmateriell eller annet innhold i Notion. Trigger på: finn siden om X, opprett en side, hent prosjektsiden, legg til i databasen, hva er IDen til, gå til Notion, åpne siden for."
---

# NOVOOI – Notion Navigasjon

## Steg 1: Les kartfilen først, hvis den finnes

Før du gjør noe Notion-søk eller -oppslag: se etter kartfilen `notion-map.md` (i prosjektets filer, i mappen brukeren har koblet til, eller i Drive). Den inneholder kjente sider, databaser og ID-er. Finner du siden der, bruk ID-en direkte i stedet for å søke.

Finnes ikke kartfilen: søk deg frem (se «Søke etter noe ukjent» under), og tilby brukeren å opprette `notion-map.md` med tabellformatet i Steg 4, slik at senere oppslag går raskere.

## Steg 2: Naviger med ID

Bruk alltid `notion-fetch` med en kjent ID fremfor `notion-search` med tekstsøk. Direkte ID-oppslag er raskere og mer pålitelig.

```
notion-fetch(id: "<page-id-fra-kartfilen>")
```

Hvis du må søke, hold `page_size` lav (5–10) og `max_highlight_length` til 0.

## Steg 3: Del URL direkte

Del alltid den fullstendige `notion.com`-URLen til brukeren. Format:
`https://app.notion.com/p/<id-uten-bindestreker>`

## Steg 4: Oppdater kartfilen når du finner nye sider

Hvis du navigerer til en side eller database som **ikke** er i kartfilen, legg den til umiddelbart:

```
| Sidenavn | `<page-id>` | https://app.notion.com/p/<id> |
```

Legg den til i riktig seksjon i kartfilen og oppdater "Sist oppdatert"-datoen øverst.

---

## Workspace-struktur (rask referanse)

| Seksjon | Hva finnes der |
|---------|----------------|
| 🎒 OPPSTART NOVOOI | Onboarding, kontoer, wifi, kontakter |
| 📱 Marcus - Arbeidsplass | Personlig dashboard, tasks, kalender |
| 🤩 PROSJEKTER | Alle prosjekter (HB, MUNCH, Fuglen, Paris, osv.) |
| ❤️ KOMMUNIKASJON | PR, influensere, journalister, SoMe, LinkedIn |
| ⏰ INVESTOR + TILSKUDD | Investorlister, tilskudd, KPIer, pitch |
| 🤑 SALG | B2B pipeline, B2C ordre, leverandøroversikt, møter |
| REGNSKAP | Regnskapsnotater og kontoføringer |
| 🧑‍💻 PLATFORM + TECH | WooCommerce, UX, Claude AI Agents, WP-admin |
| Teamspace Home | Felles team-side (lite brukt) |

**Globale databaser:** My Tasks · Home views · BACKLOGG · Showroom overview

---

## Nyttige mønstre

**Finne en prosjektside:**
1. Les kartfilen → finn prosjektnavnet under PROSJEKTER
2. Bruk `notion-fetch` med IDen

**Legge til en ny oppgave i en database:**
1. Les kartfilen → finn `collection://`-IDen for riktig database
2. Bruk `notion-create-pages` med `data_source_id` som parent

**Søke etter noe ukjent:**
1. Sjekk kartfilen først
2. Hvis ikke der: `notion-search` med kortfattet query, `page_size: 5`
3. Legg til IDen i kartfilen etterpå
