---
name: google-drive-navigation
description: "hvordan claude skal navigere NOVOOI drive mappestruktur. Bruk alltid denne skillen når noen spør om å finne filer, mapper, bilder, fakturaer, dokumenter eller annet i Google Drive."
---


# NOVOOI – Google Drive Navigasjon

## Viktig: IDer er innebygd i denne skillen

Du trenger ikke lese noen cache-fil. Alle kjente mappe-IDer er listet nedenfor — bruk dem direkte.

**Root-mappe (NOVOOI):** `1NQQ3_NKWpO3DaMtMJuGfTN6L6rUseDL0`  
Drive-eier: NOVOOI-kontoen til daglig leder

---

## Søkestrategi

### Bruk parentId — ikke tittel-søk
Naviger alltid med `parentId = '<id>'`. Det er direkte og mye raskere enn å skanne hele Drive.

### Kombiner parentId + fullText for innholdssøk
Når du leter etter noe spesifikt innenfor en kjent mappe, kombiner begge:
```
parentId = '<id>' and fullText contains 'søkeord'
```
Dette er raskere enn å liste alt og filtrere selv.

### fullText alene — kun som siste utvei
Bruk `fullText contains 'søkeord'` uten parentId bare hvis du ikke vet hvilken mappe du skal se i.

### Del alltid viewUrl direkte
Del `viewUrl` fra søkeresultatet rett til brukeren. Aldri last ned eller dekod filer.

---

## Mapper med IDer

| Mappe | ID | Innhold |
|---|---|---|
| **0. Identity** | `1cWrK5LQMgOsQt4zU2LTwRDfRH-c6ING4` | Logo, assets, templates, fonts |
| **1. Sales** | `16F0wOek7XIF79HGj_FRtT3jbDLavdqmo` | Salgsmateriale, kundecaser, logistikk |
| **1. Projects** | `1o_kmPHgrtfPhWZqORpNMB9mp9n1Qpy08` | Aktive og avsluttede prosjekter |
| **1. Investors** | `1naFqjlmbNTm_tsisdvgYcpY3XN_xFOlN` | Investordokumentasjon |
| **1. PRISLISTE** | `1Tu7KEfyeVL0t1Hd_9Zv9bWGwihvcjS8N` | Prislister |
| **2. Team** | `1TyxyFDXmj0l6cRzu_MLkjyNpXZUXeO45` | Teamdokumenter, kontrakter, onboarding |
| **2. Team Pics** | `10lqveeFKtB3AmpgEShNtCmHsrLs1FRQy` | Teambilder |
| **3. Styre** | `1XSKLkkXtH9w9TBGtkzpHHgLnYJ1hyhWp` | Styredokumenter, referat, vedtak |
| **3. Showroom** | `1Uv25WiNqLpGmNQFOIn0BV7G6CAqZe2Fh` | Showroom-innhold: kunst (inkl. "Kunst fra KOSK"), møbleringsplan, utstilleroversikt, produktbilder per brand |
| **4. Brands** | `1_mod7TCGlRHxMdDf5HYrskq9X3OmF_qn` | Én undermappe per brand (se brandliste nedenfor) |
| **4. Content** | `1-3IN82EF5bdx_88bOxtBxP-WevAw2A6M` | SoMe, nyhetsbrev, kampanjer |
| **4. Exhibitions** | `18z1BBM0QZtscX4EMq1dft-AI5cT-1KWs` | Utstillinger og kolleksjoner |
| **4. Onboarding selgere** | `1Wyrbi6ZQR7esTl2T-rKj6OvQfcWhvhC8` | Onboarding-materiale for selgere |
| **5. Marketing** | `1Q0SQTzp9EaC1YDl4bNvVCUocsU_9IUH9` | Instagram, PR, annonser |
| **6. Tilskudd/Funding** | `1pd8G4OARcV_9fhLPKKb10mWhLZeHzAaR` | Støtteordninger, søknader, rapporter |
| **7. Innsikt** | `14BkoV2RrRmM-wyRc070I1qtkKT3mqST5` | Analyser, markedsresearch, innsikt |
| **8. Accounting** | `1QHDvmE8dnvkN1rK69ZRM7aQjMSZR-fUj` | Regnskap, fakturaer, bilag (organisert per år) |
| **9. Prismodell og vilkår** | `1ZVlyUzuoixRGigvUmTfkeulNJ1CvZT56` | Prismodeller og standard vilkår |
| **10. Bedriftsnettverk** | `1694w9UT48GO3mhy46MnT58bcE-56LzZd` | Nettverksrelaterte dokumenter |
| **11. TECH** | `1B_1oLzeBrc63YbzPGT2dcpUhvi-wtdA8` | Tekniske dokumenter og systemer |
| **11. Bærekraftsstrategi** | `1NPhHIprPoxHejkRbAlR9AbvUg2cspoZp` | Bærekraft og strategi |
| **12. Interior projects** | `1gMPLnavBUC2NBUiyqha2UfcmD0aW2hps` | Innredningsprosjekter |
| **13. Frakt og logistikk** | `1mZEoJisATt-OO4ZwLdCRjAleXXxPF_j_` | Frakt, logistikk, leverandører |
| **14. Presentations** | `1wwzprzuTbqyj2zEEttO-yZEt9Z-LRTrX` | Presentasjoner |
| **15. Rekruttering** | `1-obAdzK79POzejEmTk_1d4KVraWbaT5_` | Rekrutteringsdokumenter, stillingsutlysninger |
| **16. Claude** | `1aoVdBVImKctwrr9zv7FNKWqs2RitX1AZ` | Cache og Claude-relaterte filer |

### Andre mapper (uten nummer)

| Mappe | ID |
|---|---|
| Admin | `1bgNpHD4uVqeIMHnW9oDPFA3cyrUBP1TU` |
| Kvitteringer | `1AI88RukJM7JoRlBNpAHsuPnVO29zjrJa` |
| Co-Founder agreements | `1mZqIt8WXlForM4_3Hjw1-P8akUei6xDE` |
| IP documents | `1XDUgNBeYfLVf7SVpuSaH5i67JePyS24u` |
| Ansatte | `1H4nhU4Kyz5EXFFnpeBjIrHEgDyypr4ze` |
| Pitch presentasjon | `1Pr0yvrKQamQBkmdUkKLfANXC_QMDZagx` |
| Samarbeidspartnere | `1wkMWauEAtuGtLMmlU5pHBgnHRiE468Jy` |
| Location contracts | `1G_VR9oO1wNyJY_J-euwMFJe72QVdluwn` |
| Innsalg | `1LVgPPDqeBoPiZ0cxhj1zvWmRvP4DwLuT` |
| Eksport | `1nYH_m6680ZOhP1U8jmA8FgmrOhpzNMlk` |
| Styremøter | `10uBTz90t9jAYVFYD1BD0ImPHfeQ7oYA1` |
| Investor Campaign | `10VchWn5JvqOTpVsKAB7UayfrSszeKcxO` |
| Annonser konsept | `16T2wBroiTictoSEv2OQ9p6dzFhaxjumM` |
| Artikler og presse | `136yOjzF2wftsx2hUixlOL-9lINLjBdQf` |
| Innovasjon Norge Utekontor | `1TF18eRo3N8bjIfoiy0yzfZ8Eps-AITM2` |
| Press | `16PXgsoyV6-Kc_7I69vOht9QS_Pd47hop` |
| Services | `14_1dPF5MwaRD8sWiCQe0SU4MPbo2PqqV` |
| About - Novooi | `1oxZr1wkSssLyA3zePo46dKY0oHww56X8` |
| Novooi Obsidian | `1D1CO7Cwvn1wd5Spmk1auW3fe0INPnBeV` |
| NFT gallery | `1cgbHg43wnpNGJ6ZI8gNAXe3sX_Vs8DIG` |
| Nettbutikk ordre | `1Xr39ItZHCIKWehxymUac2eQqXlh49vp-` |
| Christmas Card | `1_OPQ8DCb8Cr2lj0RCFacXN99axa0-oXN` |
| 2023 | `1F8tzLEXI75Pquk9ox9o1TMYI7sDi4yfB` |
| Atelie x Novooi | `1FWiHa3F8xlVGiSHA7j7lmaz6CieTygLw` |

---

## Brands i 4. Brands (juni 2026)

&Tradition, Abate, All Pine Press, Anna Maria Øfstedal Eng, Apen Apen, Ayla Gürsoy, Bergskog, Bjørk, Bokhari, Elisabeth Kongsrud, ESP, Figgjo, Fjordfiesta, Gudrun, Guri Sandvik, Hadeland Glassverk, Handcrafted OSL, Hedsom Jewlery, Heymat, HLIN, Holdbart Håndverk, Ida Siebke, Kaja Dahl, Karoline Hjorth, KOGL, LK Hjelle, Linda Flø, Linn Ellevseth, Lunnheim, Matre, Ment, Minus, Mykle, NAAZ, Nesje, NovaFelix, Norwegian Trash, NUEN _ Minus, NYKR, Ole Brodersen, Papiret Forlag, Philipp von Hase, Plesner Patterns, (re)made, Sol Seok, Studio FriDesign, Svane, Torsteinssen Design, Varier, Vinduet Vintage, Volver Studios.

For å finne en spesifikk brand: søk med `parentId = '1_mod7TCGlRHxMdDf5HYrskq9X3OmF_qn' and title contains 'Brandnavn'`.