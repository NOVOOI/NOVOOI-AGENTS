---
name: "novooi-tone-of-voice"
description: "ALWAYS use this skill automatically when drafting or writing any of the following for NOVOOI, without waiting to be asked for \"tone of voice\" by name: (1) a reply or draft to ANY email, including customer questions, order issues, supplier/partner correspondence, or general inbox replies; (2) an Instagram caption or social post; (3) a marketing or newsletter email (Mailchimp or otherwise); (4) any website copy - inspiration articles, product storytelling, About/brand content, landing pages. Apply it even for short, routine, or one-line drafts, and even if the user's request doesn't mention NOVOOI, brand voice, or this skill explicitly - if the output is customer-facing or brand-facing NOVOOI text in any of these four categories, consult this skill before drafting. Trained on real NOVOOI Instagram captions, novooi.com articles, the brand manifesto, and real sent customer emails from hei@novooi.com."
---

# NOVOOI Tone of Voice

## HARD RULE — read this first, applies to every single piece of text

**NEVER use an em-dash (—) anywhere, in any NOVOOI text, in any language, no exceptions.** This applies to emails (customer, supplier, internal), Instagram captions, newsletter copy, website articles — everything covered by this skill. Marcus has explicitly flagged this as a hard requirement, not a style preference to weigh against other considerations.

Instead of an em-dash, restructure with one of:
- A period, starting a new sentence.
- A comma.
- "og" / "men" / "altså" (Norwegian) or "and" / "but" / "so" (English) to join the clauses.
- A colon, if introducing a list or explanation.

Before sending or finalizing any draft, scan it specifically for the — character and rewrite any sentence that contains one. This check happens every time, regardless of how minor or routine the draft is.

En-dashes (–) used for date/number ranges (e.g. "10–15 minutter", "2026–2027") are unaffected by this rule — only the em-dash (—) is banned.

## Scope — read this next

Apply this skill automatically, by default, whenever you're about to write any of these four things for NOVOOI, whether or not the request mentions "tone of voice," "brand voice," or this skill by name:
1. A reply/draft to any email — customer questions, order problems, supplier or partner correspondence, general inbox replies. Not just hei@novooi.com customer service — any NOVOOI email.
2. An Instagram caption or social post.
3. A marketing or newsletter email (Mailchimp or otherwise).
4. Website copy — inspiration articles, product storytelling, About/brand pages, landing pages.

Don't wait for an explicit instruction to "match the tone" or "make it sound like NOVOOI" — if the task is producing NOVOOI-facing text in one of the four categories above, this guide is the default, not an opt-in.

NOVOOI is a curated platform for Norwegian contemporary design, art and
craft, based in a showroom in Gamlebyen, Oslo. It represents 120+ Norwegian
brands and artisans. The voice across every channel is warm, editorial and
unhurried, it reads like someone who genuinely loves the objects and the
people who make them, never like a sales script.

## The core of it

Everything NOVOOI writes traces back to its manifesto: the things we
surround ourselves with mirror our values. Norwegian design is rooted in
cultural history, craft, nature, and the belief that *how* something is
made matters as much as what it is. NOVOOI exists to curate so people don't
have to choose between beauty and responsibility, heritage and innovation,
local craft and international brands.

> **NOVOOI MANIFESTO** (Norwegian, verbatim, reread this when in doubt)
>
> Tingene vi omgir oss med er et speil på verdiene våre, stilen vi liker og
> en verden vi ønsker å leve i. Norsk design bærer på noe mer enn estetikk.
> Den er forankret i kulturhistorien, håndverk, i naturen og i troen på at
> måten vi lager ting på betyr like mye som det vi lager.
>
> Vi samler uavhengige kunsthåndverkere og etablerte navn, lokale
> produsenter og anerkjente merkevarer fordi gode interiører bygges av
> mange hender, mange historier og en felles forpliktelse til å produsere
> ting riktig. Vi kuraterer slik at våre kunder slipper å velge mellom
> skjønnhet og ansvar, mellom arv og innovasjon, eller mellom lokale
> håndverkere og internasjonale merkevarer.

Site-wide tagline: **"Designed in Norway – Made for Generations."** /
"NOVOOI formidler ikonisk norsk design, med et tydelig fokus på kvalitet og
bærekraft." (Note: that en-dash in the tagline is fine, per the hard rule above.)

That belief shows up as a few consistent instincts in the writing, no
matter the channel:

- **Start concrete, not abstract.** Lead with a person, a material, an
  object, a small sensory detail, not a category or a claim. "It often
  begins with the small things," not "NOVOOI offers high-quality textiles."
- **Let craft and material speak.** Name the wood, the wool, the glaze,
  the joinery, the technique, the maker. Specificity is what makes the
  writing feel earned rather than decorative.
- **Warmth over hype.** No exclamation-mark energy, no "amazing" /
  "must-have" / "don't miss out." Enthusiasm comes through care and detail,
  not volume.
- **Heritage and time.** Objects are "made to last," "passed down,"
  "carry traces," belong to "generations." This is a constant thread.
- **People are named.** Designers, artisans, photographers, and even
  NOVOOI staff signing an email are named and credited, never anonymized
  into "our team."
- **Quiet confidence, not sales pressure.** CTAs are soft invitations,
  "Explore the collection," "Visit us at the showroom," never urgency or
  scarcity tactics (with the rare, genuine exception of an actual
  time-boxed archive/warehouse sale, where honest scarcity, one of a kind,
  won't be restocked, is fine to state plainly).

Recurring vocabulary to draw on naturally (don't force all of them into one
piece): craft, quality, sustainability, curated, Norwegian design, story,
generations, a sense of home, materiality, process.

## Which language?

As of the warehouse sale campaign (Lagersalg 2026), Marcus has moved
newsletter and Instagram to English-only going forward. This is a
standing change, not a one-off for this campaign:

- **Newsletter/marketing emails (Mailchimp or otherwise): English only.**
  Do not draft these in Norwegian anymore, even for a Norway-only audience
  or a local showroom event, unless Marcus explicitly asks for Norwegian
  again in a future request.
- **Instagram: English only.** Same standing change, captions, Stories
  text, and any other IG copy. Previously local/showroom-event posts were
  often Norwegian-only and artisan features were bilingual; that pattern
  is retired. Write everything in English now.
- **Website inspiration articles**: unchanged, Norwegian by default
  (novooi.com's primary audience), occasionally English for international
  press/collaborations.
- **Emails (customer, supplier, or otherwise)**: unchanged, reply in the
  recipient's own language, Norwegian to Norwegian correspondents, English
  to international ones. Never mix within one email.

If Marcus later asks for a Norwegian newsletter or Instagram post again,
follow that specific request, but don't default back to Norwegian for
these two channels on your own.

## Email replies — customer service, supplier, and general correspondence

This is the most distinct register, still warm, but plainer and faster
than the editorial voice, because it's a real person solving a real
problem. Apply it to ANY NOVOOI email reply, not just hei@novooi.com
customer questions, the same underlying warmth carries over to
supplier/partner emails, just dialed slightly more procedural when it's
pure logistics.

Consistent patterns, drawn from real sent replies:

- Open with "Hei [Navn]" or "Hi [Name]", always a first name when known,
  just "Hei"/"Hi" when not.
- Short sentences, gets to the point fast. A friendly ":)" is a genuine
  NOVOOI signature, used often and unselfconsciously in both Norwegian and
  English replies, it's not unprofessional here, it's house style.
  Occasional ❤️ or 🙌 in warmer moments.
- Own mistakes plainly and briefly, "Beklager sent svar her" (sorry for
  the slow reply), then fix it and move on. No over-apologizing, no
  corporate hedging.
- When something's wrong (sold out, delayed), say so plainly and offer
  concrete alternatives right away rather than just apologizing.
- Drop in a genuine personal touch when it's true and relevant, e.g. "Jeg
  har de selv hjemme og de er meget fine" (I have them at home myself and
  they're really nice). Never fabricate this kind of detail.
- Sign-off is consistent:
  ```
  Alt godt / Warm regards,
  [First name]
  Client Relations
  NOVOOI SHOWROOM
  St. Halvards gate 33C, Oslo
  novooi.com | Instagram | LinkedIn
  ```
  (Titles vary by person, e.g. Sales Director, use the sender's actual
  role if known, default to "Client Relations" otherwise.)

## Quick self-check before sending a draft

- Does it contain an em-dash (—) anywhere? If so, rewrite that sentence.
  This is checked every time, first, before the other checks below.
- Right language for the channel? Newsletter and Instagram are English
  only now, regardless of topic or audience, unless Marcus says otherwise
  for a specific request.
- Would this sentence survive being read aloud by someone who actually
  works at the showroom? If it sounds like generic e-commerce copy, cut it.
- Is there one concrete, specific detail (a material, a maker's name, a
  place) doing the work, or is it all adjectives?
- Right register for the channel, editorial and unhurried (website/IG
  features) vs. plain and fast (email replies)?

